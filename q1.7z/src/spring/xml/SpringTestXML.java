package spring.xml;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
@Configuration
public class SpringTestXML
{
    private static final String NAME = "Parag Joshi";

    @Test
    public static void main(String[] args)
    {
        /*Resource resource = new ClassPathResource("applicationContext.xml");
        BeanFactory factory = new XmlBeanFactory(resource);*/

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");

        Product product = (Product) applicationContext.getBean("productBean");
        product.displayInfo();

        Person personSingletonA = (Person) applicationContext.getBean("personSingleton");
        Person personSingletonB = (Person) applicationContext.getBean("personSingleton");
        personSingletonA.setName(NAME);

        System.out.println("personSingletonA: " + personSingletonA);
        System.out.println("personSingletonB: " + personSingletonB);
        Assert.assertEquals(NAME, personSingletonB.getName());
    }
}
