package spring.annotation;

import java.util.List;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
public class Product
{
    private List<Item> items;

    public Product(List<Item> items)
    {
        this.items = items;
    }

    /*public Product()
    {

    }*/

   /* public void setItems(List<Item> items)
    {
        this.items = items;
    }

    public List<Item> getItems()
    {
        return items;
    }*/

    public void displayInfo()
    {
        for (Item item : items)
            System.out.println("Hello: " + item.getName());
    }

}
