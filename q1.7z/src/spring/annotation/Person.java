package spring.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
public class Person
{
    private String name;

    public Person()
    {

    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}
