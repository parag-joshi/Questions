package spring.annotation;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
public class Item
{
    String name;

    public Item()
    {

    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}
