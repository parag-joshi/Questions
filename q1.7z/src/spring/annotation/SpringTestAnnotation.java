package spring.annotation;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import java.util.Arrays;
import java.util.List;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
@Configuration
public class SpringTestAnnotation
{
    private static final String NAME = "Parag Joshi";

    @Bean
    @Scope("singleton")
    public Person personSingleton()
    {
        return new Person();
    }

    @Bean
    @Scope("prototype")
    public Item car()
    {
        return new Item();
    }

    @Bean
    @Scope("prototype")
    public Item bus()
    {
        return new Item();
    }

    @Bean
    @Scope("singleton")
    public Product productSingleton()
    {
        return new Product(items());
    }

    @Bean
    public List<Item> items()
    {
        return Arrays.asList(car(), bus());
    }

    @Test
    public static void main(String[] args)
    {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
        applicationContext.scan("spring.annotation");
        applicationContext.refresh();

        Product productSingleton = applicationContext.getBean(Product.class);
        productSingleton.displayInfo();

        //System.out.println("Bean names: " + Arrays.toString(applicationContext.getBeanNamesForType(Person.class)));
        Person personSingletonA = applicationContext.getBean(Person.class);
        Person personSingletonB = applicationContext.getBean(Person.class);

        personSingletonA.setName(NAME);


        System.out.println("personSingletonA: " + personSingletonA);
        System.out.println("personSingletonB: " + personSingletonB);
        Assert.assertEquals(NAME, personSingletonB.getName());
    }
}
