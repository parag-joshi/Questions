package leetcode;

import java.util.Arrays;

/**
 * @author Parag.Joshi on 08-Apr-2021.
 */
public class TwoAddition
{
    public static void main(String[] args)
    {
        int[] nums = new int[]{3, 2, 4};
        int target = 6;
        System.out.println(Arrays.toString(twoSum(nums, target)));
        reverseString(new char[]{'h', 'e', 'l', 'l', 'o'});
    }

    private static int[] twoSum(int[] nums, int target)
    {
        int length = nums.length;

        if (length < 2 || length > Math.pow(10, 3))
            throw new RuntimeException("The length of input array is invalid!");

        if (target < Math.pow(-10, 9) || target > Math.pow(10, 9))
            throw new RuntimeException("The target is either too short or big!");

        for (int input : nums)
            validateInput(input);

        int[] positions = new int[2];

        for (int i=0; i<length; i++)
        {
            positions[0] = i;
            for (int j=i+1; j<length; j++)
            {
                if (nums[j] == target - nums[i])
                {
                    positions[1] = j;
                    return positions;
                }
            }
        }

        //return recursiveTwoSum(0, length - 1, nums, target);

        throw new RuntimeException("No such positions found!");
    }

    private static int[] recursiveTwoSum(int start, int length, int[] nums, int target)
    {
        int[] positions = new int[2];
        positions[0] = start;

        for (int i = start; i < length; i++ )
        {
            if (nums[i + 1] == target - nums[i])
            {
                positions[1] = i + 1;
                return positions;
            }
            if (positions[1] == 0)
                recursiveTwoSum(i + 1, length, nums, target);
        }
        throw new RuntimeException("No such positions found!");
    }

    private static void validateInput(int target)
    {
        if (target < Math.pow(-10, 9) || target > Math.pow(10, 9))
            throw new RuntimeException("The target is either too short or big!");
    }

    public static void reverseString(char[] s) {

        if (s.length < 1)
            throw new RuntimeException("String must be of non-zero length!");

        if (s.length > Math.pow(10, 5))
            throw new RuntimeException("String cannot be more than 10000 characters!");

        String original = new String(s);
        String reverse = new StringBuilder(original).reverse().toString();

        System.out.println("Reversed string: " + reverse);
    }
}
