package tudipassignment;

/**
 * Created by Parag.Joshi on 10-Sep-22.
 */
public class StringSpaceRemover
{
    public static void main(String[] args)
    {
        String inputStr = "      Write a program     to remove all the   extra spaces    from a\n" +
                            "paragraph/string";
        String strWithoutExtraSpaces = inputStr.replaceAll("\\s+", " ").trim();
        System.out.println(strWithoutExtraSpaces);
    }
}