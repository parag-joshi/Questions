package tudipassignment;

/**
 * Created by Parag.Joshi on 10-Sep-22.
 */
public class HelloWorld
{
    public static void main(String[] args)
    {
        System.out.println(isDivisibleByFiveOrSeven(43));
    }

    private static String isDivisibleByFiveOrSeven(int num)
    {
        return ((num % 5 == 0) ? (num % 7 == 0 ? "Hello World" : "Hello") : (num % 7 == 0 ? "World" : "Neither divisible by 5 nor 7"));
    }
}