package findoutput;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author Parag.Joshi on 24-Dec-2021.
 */
public class IteratorExample
{
    public static void main(String[] args)
    {
        HashMap map = new HashMap();
        map.put("ABC", "PQR");
        map.put(null, "PQR");
        map.put("null", "PQR");
        map.put(null, "XYZ");
        map.put("ABC", "ABC");
        System.out.println(map.size());

        Iterator itr = map.keySet().iterator();
        while (itr.hasNext())
        {
            map.remove(itr.next());
        }
        System.out.println(map.size());

        // Following list is immutable so iterator.remove() will throw UnSupportedOperationException
        Collection<Integer> list = Arrays.asList(9, 29, -1, 11, 1, 0, 1);
        //Collection<Integer> list = new ArrayList<>(Arrays.asList(9, 29, -1, 11, 1, 0, 1));

        System.out.println("List before: " + list);
        Iterator iterator = list.iterator();

        while (iterator.hasNext())
        {
            Integer i = (Integer) iterator.next();

            if (i < 1 || i > 10)
                iterator.remove();
                //list.remove(i);
        }
        System.out.println("List after: " + list);

// create an instance of
        // ConcurrentHashMap

    }
}
