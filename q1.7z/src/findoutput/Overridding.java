package findoutput;

/**
 * @author e1078130
 */
public class Overridding
{
	public static void main(String[] args)
	{
		A a = new B();
		a.m1();
		//a.m2();
	}
}

class A
{
	void m1() throws ArrayIndexOutOfBoundsException
	{
		System.out.println("In m1 A");
		privateMethod();
	}

	private void privateMethod()
	{
		System.out.println("Super!");
	}

}

class B extends A
{
	void m1() throws IndexOutOfBoundsException
	{
		System.out.println("In m1 B");
		privateMethod();
	}
	void m2()
	{
		System.out.println("In m2 B");
	}

	private void privateMethod()
	{
		System.out.println("Sub!");
	}
}
