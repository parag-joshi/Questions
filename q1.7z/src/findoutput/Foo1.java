package findoutput;

/**
 * Created by e1078130 on 07-Aug-22.
 */
//@FunctionalInterface
public interface Foo1
{
    String method(String string);
    /*default void defaultBaz()
    {
        System.out.print("Foo1");
    }*/

}
