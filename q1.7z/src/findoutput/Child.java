package findoutput;

import simpleprograms.DuplicateElements;

import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Parag.Joshi on 14-Sep-2021.
 */
public class Child extends Parent
{
    public Integer doIt (ArrayList a) throws IOException
    {
        return new Integer(2);
    }
}
