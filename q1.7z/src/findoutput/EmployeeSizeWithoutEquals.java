package findoutput;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */

public class EmployeeSizeWithoutEquals
{
	public static void main(String[] args)
	{
          Employee e1 = new Employee(1, "Ramesh");
          Employee e2 = new Employee(1, "Ramesh");
          
          Set<Employee> set = new HashSet<Employee>();
          set.add(e1);
          set.add(e2);
          System.out.println(set.size());
	}
}
