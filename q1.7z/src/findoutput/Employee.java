package findoutput;

import java.util.Objects;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */
class Employee implements Comparable
{
	private int id;
	private String name;
	
	Employee(int id, String name)
	{
		this.id = id;
		this.name = name;
	}

    public int getId()
	{
    	return id;
    }

	public String getName()
	{
		return name;
	}

    @Override
    public boolean equals(Object obj)
    {
    	if (this == obj)
            return true;
       
    	if (obj == null || getClass() != obj.getClass())
            return false;

    	Employee other = (Employee) obj;
    	
    	boolean isSameId = id == other.id;
    	boolean isSameName = Objects.equals(name, other.name);
    	
    	return isSameId && isSameName;
    }
   
    @Override
    public int hashCode()
    {
    	return Objects.hash(id);
    }
    
    @Override
    public int compareTo(Object o)
    {
		Employee e = (Employee) o;
		Integer thisId = this.getId();
    	Integer otherId = e.getId();
    	
    	return thisId.compareTo(otherId);
	}

	@Override
	public String toString()
	{
		return "Employee: {" +
				"id: " + id + ", " +
				"name: " + name +
				"}";
	}

	public boolean isValidEmployee()
	{
		return true;
	}

	public boolean isValidEmployee(Employee employee)
	{
		return true;
	}
}
