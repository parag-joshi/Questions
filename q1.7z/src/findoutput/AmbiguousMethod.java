package findoutput;

/**
 * @author Parag.Joshi on 25-Feb-2021.
 */
public class AmbiguousMethod
{
    public static void main(String[] args)
    {
        test(null);
    }

    private static void test(Object o)
    {
        System.out.println("Object implementation ");
    }

    private static void test(String s)
    {
        System.out.println("String implementation ");
    }

    /*private static void test(Integer i)
    {
        System.out.println("Integer implementation ");
    }*/
}
