package findoutput;

import java.util.*;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */
public class EmployeeSizeWithEqualsAndCompareTo
{
	public static void main(String[] args)
	{
          Employee e1 = new Employee(1, "Ramesh");
          Employee e2 = new Employee(1, "Suresh");

          Set<Employee> treeSet = new TreeSet<Employee>();
          treeSet.add(e1);
          treeSet.add(e2);
          System.out.println(treeSet.size());
	}

}

