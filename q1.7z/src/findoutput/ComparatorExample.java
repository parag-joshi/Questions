package findoutput;

/**
 * @author Parag.Joshi on 05-Dec-2021.
 */
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;

public class ComparatorExample
{
    public static void main(String[] args)
    {
        List<Employee> employees = new ArrayList<>();

        employees.add(new Employee(1, "Parag"));
        employees.add(new Employee(2, "Aditya"));
        employees.add(new Employee(3, "Ajinkya"));

        // print before sorting
        System.out.println(" (1) Before sorting: " + employees);

        Comparator<Employee> employeeNameComparator = new Comparator<Employee>() {

            @Override
            public int compare(Employee e1, Employee e2)
            {
                return e1.getName().compareTo(e2.getName());
            }
        };


        Comparator<Employee> employeeNameComparatorLambda = (e1, e2) -> e1.getName().compareTo(e2.getName());

        Comparator<Employee> employeeNameComparatorDefault = Comparator.comparing(Employee::getName);

        // sort the list
        Collections.sort(employees, employeeNameComparator);

        // print after sorting
        printEmployeesAfterSorting(employees, 2);

        // reverse the order
        Collections.sort(employees, Collections.reverseOrder());
        printEmployeesAfterSorting(employees, 3);

        employees.sort(null);
        Collections.reverse(employees);
        printEmployeesAfterSorting(employees, 4);

        employees.sort(Collections.reverseOrder());
        printEmployeesAfterSorting(employees, 5);

        Collections.sort(employees, Collections.reverseOrder(employeeNameComparator));
        printEmployeesAfterSorting(employees, 6);

        Collections.sort(employees, employeeNameComparator.reversed());
        printEmployeesAfterSorting(employees, 7);

        Comparator<Employee> employeeNameComparatorLambdaReverse = (e1, e2) -> e2.getName().compareTo(e1.getName());
        Collections.sort(employees, employeeNameComparatorLambdaReverse);
        printEmployeesAfterSorting(employees, 8);
    }

    private static void printEmployeesAfterSorting(List<Employee> employees, int i)
    {
        System.out.print(" (" + i + ") After sorting: ");
        for (Employee e : employees)
            System.out.print(e.getName() + " ");
        System.out.println("");
    }
}
