package findoutput;

/**
 * @author Parag.Joshi on 27-Dec-2021.
 */
public class Version
{
    private int release;

    private int revision;

    private int patch;

    public Version(int release, int revision, int patch)
    {
        this.release = release;
        this.revision = revision;
        this.patch = patch;
    }

    public String toString()
    {
        return "(" + this.release + "." + this.revision + "." + this.patch + ")";
    }

    //public boolean equals(Object obj)
    public boolean equals(Version obj)
    {
        if (obj == this)
            return true;

        if (!(obj instanceof Version))
            return false;

        Version other = (Version) obj;

        return this.release == other.release
               && this.revision == other.revision
               && this.patch == other.patch;

    }
}
