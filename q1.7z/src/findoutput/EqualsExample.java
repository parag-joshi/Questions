package findoutput;

import java.util.*;

/**
 * @author Parag.Joshi on 27-Dec-2021.
 */
public class EqualsExample
{
    public static void main(String[] args)
    {
        new EqualsExample().test();
    }

    private void test()
    {
        Version ref1 = makeVersion(2022, 1, 0);
        Version ref2 = makeVersion(2022, 1, 0);
        Object ref3 = ref2;

        System.out.println("ref1 == ref2: " + ref1.equals(ref2));
        System.out.println("ref1 == ref3: " + ref1.equals(ref3));

        Object[] versions = {makeVersion(2020, 1, 0), makeVersion(2021, 1, 0), makeVersion(2022, 1, 0)};
        Integer[] downloads = {121, 57, 0};


        Map<Object, Integer> versionStats = new HashMap<>();
        for (int i=0; i<versions.length; i++)
            versionStats.put(versions[i], downloads[i]);
        System.out.println("Version statistics: " + versionStats);

        Object searchKey = ref1;

        for (Object o : versions)
            System.out.println("Hashcode of " + o + ": " + o.hashCode());

        System.out.println("Hashcode of searchKey: " + searchKey.hashCode());
        System.out.println("Map contains search key: " + versionStats.containsKey(searchKey));


        /*List<Object> versionList = Arrays.asList(versions);
        System.out.println("Sorted list: " + new TreeSet<>(versionList));*/
    }

    private Version makeVersion(int release, int revision, int patch)
    {
        return new Version(release, revision, patch);
    }
}
