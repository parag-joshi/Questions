package findoutput;

/**
 * Created by e1078130 on 07-Aug-22.
 */
public class FooClass implements Foo
{
    @Override
    public String method(String string)
    {
        return null;
    }

    public static void main(String[] args)
    {
        Foo1 foo1 = new FooClass();
        Foo2 foo2 = new FooClass();
    }
}
