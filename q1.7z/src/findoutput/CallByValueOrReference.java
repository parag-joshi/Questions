package findoutput;

/**
 * @author Parag.Joshi on 25-Feb-2021.
 */
public class CallByValueOrReference
{

    public static void main(String[] args)
    {
        Pizza favoritePizza = new Pizza();

        // Case 1
        System.out.println("Meat on pizza before baking: " + favoritePizza.meat);
        changeMeatAndBake(favoritePizza);
        System.out.println("Meat on pizza after baking: " + favoritePizza.meat);

        // Case 2
        favoritePizza = new Pizza();
        System.out.println("Meat on pizza before baking: " + favoritePizza.meat);
        createNewAndBake(favoritePizza);
        System.out.println("Meat on pizza after baking: " + favoritePizza.meat);
    }

    private static void changeMeatAndBake(Pizza pizzaToBeBaked)
    {
        pizzaToBeBaked.meat = "chicken"; // Change the meat on the pizza.
        //pizzaToBeBaked = null;
    }

    private static void createNewAndBake(Pizza pizzaToBeBaked)
    {
        pizzaToBeBaked = new Pizza("chicken"); // Create the chicken pizza.
        //pizzaToBeBaked = null;
    }
}

class Pizza
{
    String meat;

    Pizza()
    {
        meat = "beef";
    }

    Pizza(String meat)
    {
        this.meat = meat;
    }
}