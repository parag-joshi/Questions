package findoutput;

/**
 * @author Parag.Joshi on 25-Feb-2021.
 */
public class BigONotation
{
    public static void main(String[] args)
    {
        int[] items = {1, 2, 3, 4, 5};
        printFirstItemThenFirstHalfThenSayHi100Times(items);
    }

    private static void printFirstItemThenFirstHalfThenSayHi100Times(int[] items)
    {
        System.out.println(items[0]);

        int middleIndex = items.length / 2;
        int index = 0;

        while (index < middleIndex)
        {
            System.out.println(items[index]);
            index++;
        }

        for (int i = 0; i < 100; i++)
        {
            System.out.println("Hi");
        }
    }
}
