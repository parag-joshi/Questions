package findoutput;

/**
 * @author Parag.Joshi on 25-Feb-2021.
 */
public class StringImmutability
{
    public static void main(String[] args)
    {
        String str1 = "You cannot change me!";
        String str2 = "You cannot change me!";
        String str3 = "You cannot" + " change me!";

        System.out.println(str1 == str2);       //  (1)
        System.out.println(str2 == str3);       //  (2)
        System.out.println(str1 == str3);       //  (3)


        String javaStr = "Java";
        String anotherJavaStr = new String("Java");
        String fromPool = anotherJavaStr.intern();

        System.out.println(javaStr == fromPool);    //  (4)
        System.out.println(javaStr == "Java");      //  (5)
        System.out.println(javaStr.compareTo(anotherJavaStr)); //   (6)

        String _7Up = 7 + "Up";
        String another7Up = "7Up";

        System.out.println(_7Up == another7Up);     //  (7)

        String up = "Up";
        String oneMore7Up = 7 + up;
        System.out.println(_7Up == oneMore7Up);     //  (8)
    }
}
