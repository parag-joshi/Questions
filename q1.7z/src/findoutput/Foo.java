package findoutput;

/**
 * Created by e1078130 on 07-Aug-22.
 */
@FunctionalInterface
public interface Foo extends Foo1, Foo2
{
    //default void defaultBaz() {}


}
