package findoutput;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author Parag.Joshi on 29-Dec-2021.
 */
public class FailFastFailSafeExample
{
    public static void main(String[] args)
    {
        CopyOnWriteArrayList<Integer> copyList = new CopyOnWriteArrayList<>(new Integer[]{1, 3, 5, 8});
        System.out.println("List before: " + copyList);
        Iterator itr = copyList.iterator();
        while (itr.hasNext())
        {
            Integer no = (Integer) itr.next();
            System.out.println(no);
            if (no == 1)
                copyList.add(14);   // This will not be added to iterator's collection but the underlying collection
                //itr.remove();
        }
        System.out.println("List after: " + copyList);


        ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();
        map.put("ONE", 1);
        map.put("TWO", 2);
        map.put("THREE", 3);
        map.put("FOUR", 4);

        System.out.println("Map before: " + map);

        Iterator it = map.keySet().iterator();
        while (it.hasNext())
        {
            String key = (String) it.next();
            System.out.println(key + " : " + map.get(key));
            //it.remove();

            // This will reflect in iterator. The behavior is weakly consistent meaning the modifications to cloned copy may / may not be reflected to original collection.
            // In case of ConcurrentHashMap it is reflected.
            map.put("SEVEN", 7);
        }

        System.out.println("Map after: " + map);
    }
}
