package findoutput;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Parag.Joshi on 14-Sep-2021.
 */
public class Parent
{
    public int doIt (List a) throws IOException
    {
        return 1;
    }

    public static void main (String args[])
    {
        List a = new ArrayList<>();
        Parent p = new Child();
        try
        {
            System.out.println(p.doIt(a));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
