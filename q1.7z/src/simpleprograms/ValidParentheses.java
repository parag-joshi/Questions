package simpleprograms;

import java.util.Stack;

/**
 * @author Parag.Joshi on 26-Aug-2021.
 */
public class ValidParentheses
{

    public static void main(String[] args)
    {
        System.out.println(isValid("{}[]"));
        System.out.println(isValid("{[}]"));
        System.out.println(isValid("[{}]"));
    }

    private static boolean isValid(String s)
    {
        char arr[] = s.toCharArray();
        Stack<Character> set = new Stack();
        for (Character ch : arr)
        {
            if (ch == '{' || ch == '[' || ch == '(')
            {
                set.push(ch);
            }
            else if (ch == ']')
            {
                if (set.isEmpty() || set.peek() != '[')
                    return false;
                set.pop();
            }
            else if (ch == ')')
            {
                if (set.isEmpty() ||  set.peek() != '(')
                    return false;
                set.pop();
            }
            else if (ch == '}')
            {
                if (set.isEmpty() ||  set.peek() != '{')
                    return false;
                set.pop();
            }
        }

        return set.size() == 0;
    }
}
