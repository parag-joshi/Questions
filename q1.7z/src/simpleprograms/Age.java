package simpleprograms;

/**
 * @author Parag.Joshi on 25-Feb-2021.
 */
class Age
{
    private int day;
    private int month;
    private int year;

    int getDay()
    {
        return day;
    }

    void setDay(int day)
    {
        this.day = day;
    }

    int getMonth()
    {
        return month;
    }

    void setMonth(int month)
    {
        this.month = month;
    }

    int getYear()
    {
        return year;
    }

    void setYear(int year)
    {
        this.year = year;
    }
}
