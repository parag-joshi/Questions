package simpleprograms;

/**
 * Created by e1078130 on 21-Aug-22.
 */
public class Fibonacci
{

    public static void main(String args[])
    {
        int number = 5;

        // Printing Fibonacci series upto number
        for(int i=1; i<=number; i++)
        {
            System.out.print(fibonacciWithIteration(i) + " ");
        }

        System.out.println();

        // Printing Fibonacci series upto number
        for(int i=1; i<=number; i++)
        {
            System.out.print(fibonacciWithRecursive(i) + " ");
        }
    }

    private static int fibonacciWithIteration(int number)
    {
        if(number == 1 || number == 2)
            return 1;

        int num1=1, num2=1, sum=1;
        for (int i= 3; i<= number; i++)
        {
            // Fibonacci number is sum of previous two Fibonacci number
            sum = num1 + num2;
            num1 = num2;
            num2 = sum;
        }
        return sum; //Fibonacci number
    }

    private static int fibonacciWithRecursive(int number)
    {
        if(number == 1 || number == 2)
            return 1;

        return fibonacciWithRecursive(number - 1) + fibonacciWithRecursive(number - 2); // Tail recursion
    }
}
