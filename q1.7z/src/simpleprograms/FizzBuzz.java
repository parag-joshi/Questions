package simpleprograms;

import java.util.stream.IntStream;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */
public class FizzBuzz
{
    public static void main(String[] args)
    {
        fizzBuzzBeforeJava8(20);
        System.out.println("*************************************************");
        fizzBuzzInJava8(100);
    }

    private static void fizzBuzzBeforeJava8(int num)
    {
        for (int i = 1; i <= num; i++)
        {
            if (((i % 3) == 0) && ((i % 5) == 0)) // Is it a multiple of 3 & 5?
                System.out.println("FizzBuzz");
            else if ((i % 3) == 0) // Is it a multiple of 3?
                System.out.println("Fizz");
            else if ((i % 5) == 0) // Is it a multiple of 5?
                System.out.println("Buzz");
            else
                System.out.println(i); // Not a multiple of 5 or 7
        }
    }

    private static void fizzBuzzInJava8(int num)
    {
        IntStream.rangeClosed(1, num)
                .mapToObj(i -> i % 3 == 0 ? (i % 5 == 0 ? "FizzBuzz" : "Fizz") : (i % 5 == 0 ? "Buzz" : i))
                .forEach(System.out::println);
    }
}
