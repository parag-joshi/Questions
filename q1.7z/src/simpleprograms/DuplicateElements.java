package simpleprograms;

import java.util.*;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */
public class DuplicateElements
{
    public static void main(String[] args)
    {
        Integer[] array = {7,1,8,3,4,5,6,3,7,8};

        /*********************  O(n)   ****************/
        Set<Integer> set = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();

        for (Integer element : array)
        {
            if (!set.add(element))
                duplicates.add(element);
        }

        if(duplicates.isEmpty())
            duplicates.add(-1);

        System.out.println(duplicates);

        /*********************  O(2n)   ****************/
        Map<Integer, Integer> nameCountMap = new HashMap<>();
        for (Integer element: array)
        {
            Integer count = nameCountMap.get(element);
            if (count == null)
                nameCountMap.put(element, 1);
            else
                nameCountMap.put(element, ++count);
        }

        duplicates = new HashSet<>();
        Set<Map.Entry<Integer, Integer>> entries = nameCountMap.entrySet();
        for (Map.Entry<Integer, Integer> entry : entries)
            if (entry.getValue() > 1)
                duplicates.add(entry.getKey());

        System.out.println(duplicates);
    }
}
