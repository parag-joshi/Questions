package simpleprograms;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */
public class Factorial
{
    public static void main(String[] args)
    {
        System.out.println(factorialIterative(2));
        System.out.println(factorialRecursive(2));
    }

    private static long factorialIterative(long number)
    {
        long result = 1;
        for (long i = 1; i <= number; i++ )
        {
            result *= i;
        }
        return result;
    }

    private static long factorialRecursive(long number)
    {
        return number == 0 ? 1 : number * factorialRecursive(number-1);
    }
}
