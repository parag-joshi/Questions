package simpleprograms;

/**
 * @author Parag.Joshi on 23-Feb-2021.
 */
public class PalindromeString
{
    public static void main(String[] args)
    {
        System.out.println(isPalindromeString("howtodoinjava"));
        System.out.println(isPalindromeStringUsingForLoop("abcba"));
    }

    private static boolean isPalindromeString(String originalString)
    {
        String reverse = new StringBuilder(originalString).reverse().toString();
        return originalString.equals(reverse);
    }

    private static boolean isPalindromeStringUsingForLoop(String originalString)
    {
        String reverse = "";
        int length = originalString.length();

        for (int i = length - 1; i >= 0; i--)
            reverse = reverse + originalString.charAt(i);

        return originalString.equals(reverse);
    }
}
