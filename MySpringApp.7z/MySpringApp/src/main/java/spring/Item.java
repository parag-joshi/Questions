package spring;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
public class Item
{
    String name;

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}
