package spring;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.util.Arrays;
import java.util.List;

/**
 * @author Parag.Joshi on 17-Dec-2021.
 */
public class SpringTest
{
    private static final String NAME = "Parag Joshi";

    @Test
    public static void main(String[] args)
    {
        /*Resource resource = new ClassPathResource("applicationContext.xml");
        BeanFactory factory = new XmlBeanFactory(resource);*/

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");

        Product product = (Product) applicationContext.getBean("productBean");
        product.displayInfo();

        Person personSingletonA = (Person) applicationContext.getBean("personSingleton");
        Person personSingletonB = (Person) applicationContext.getBean("personSingleton");

        personSingletonA.setName(NAME);
        Assert.assertEquals(NAME, personSingletonB.getName());
    }
}
