package com.fis.kiodex.usermanagement.resource;

import com.fis.kiodex.usermanagement.model.User;
import com.fis.kiodex.usermanagement.service.UserService;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

/**
 * @author Parag.Joshi on 17-11-2019.
 */
@Path("/users")
public class UserResource
{
    private UserService userService = new UserService();

    // CREATE operation
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public List<User> createUser(User user)
    {
        return userService.createUser(user);
    }

    // READ operation
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<User> getAllUsers()
    {
        return userService.getAllUsers();
    }

    // READ operation - can also use regex e.g. @Path("/{id: [a-zA-Z][a-zA-Z_0-9]*}")
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public User getUserById(@PathParam("id") int id)
    {
        return userService.getUserById(id);
    }

    // UPDATE operation
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public List<User> updateUser(User user)
    {
        return userService.updateUser(user);
    }

    // DELETE operation
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<User> deleteUserById(@PathParam("id") int id)
    {
        return userService.deleteUserById(id);
    }
}
