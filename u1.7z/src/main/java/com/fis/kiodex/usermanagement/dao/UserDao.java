package com.fis.kiodex.usermanagement.dao;

import com.fis.kiodex.usermanagement.model.User;
import javax.ws.rs.NotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * Just to avoid DB calls in this example, assume below data is interacting with DB
 * @author Parag.Joshi on 17-11-2019.
 */
public class UserDao
{
    private static final List<User> users = createUsers();

    private static List<User> createUsers()
    {
        List<User> users = new ArrayList<>();
        users.add(new User(101, "Yogesh Mahabare", "yogesh.mahabare@fisglobal.com"));
        users.add(new User(102, "Aarti Chaudhari", "aarti.chaudhari@fisglobal.com"));
        users.add(new User(103, "Varsha Khatri", "varsha.khatri@fisglobal.com"));
        users.add(new User(104, "Piyush Gharote", "piyush.gharote@fisglobal.com"));
        users.add(new User(105, "Parag Joshi", "parag.joshi@fisglobal.com"));
        return users;
    }

    public UserDao()
    {

    }

    public List<User> getAllUsers()
    {
        return users;
    }

    public User getUserById(int id)
    {
        for (User user : users)
            if (user.getId() == id)
                return user;

        throw new NotFoundException("Resource not found with Id :: " + id);
        //return null;
    }

    public List<User> createUser(User user)
    {
        users.add(user);
        return users;
    }

    public List<User> updateUser(User user)
    {
        for (User u : users)
        {
            if (user.getId() == u.getId())
            {
                users.remove(u);
                users.add(user);
            }
        }
        return users;
    }

    public List<User> deleteUserById(final int id)
    {
        users.removeIf(user -> user.getId() == id);
        return users;
    }
}
