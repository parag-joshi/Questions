package com.fis.kiodex.usermanagement.service;

import com.fis.kiodex.usermanagement.dao.UserDao;
import com.fis.kiodex.usermanagement.model.User;
import java.util.List;

/**
 * @author Parag.Joshi on 17-11-2019.
 */
public class UserService
{
    private final UserDao userDao = new UserDao();

    public List<User> getAllUsers()
    {
        return userDao.getAllUsers();
    }

    public User getUserById(int id)
    {
        return userDao.getUserById(id);
    }

    public List<User> createUser(User user)
    {
        return userDao.createUser(user);
    }

    public List<User> updateUser(User user)
    {
        return userDao.updateUser(user);
    }

    public List<User> deleteUserById(int id)
    {
        return userDao.deleteUserById(id);
    }
}
